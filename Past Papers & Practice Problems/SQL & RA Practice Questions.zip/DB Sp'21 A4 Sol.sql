--Q1
select [User].name 
from [User]
where [User].userID IN (
select Downloads.userID 
from Developer join Game
on (developID = developerID AND Developer.name = 'Ali Uman')
join Downloads on Game.gameID = Downloads.gameID)
 
 --Q2
select [User].name from [User]
where NOT EXISTS (
(select Game.gameID from Game join Developer on Game.developID = Developer.developerID
AND Developer.name = 'Ali Uman')
except
(select Downloads.gameID from Downloads where Downloads.userID = [User].userID)
)

--Q3
select A.name, A.userID, A.country 
from [User] as A 
where A.age IN (select min(age) from [User] as B where 
A.country = B.country 
group by B.country)

--Q4
select Developer.country,count(*) as [No of Developers]
from Developer 
where Developer.country IN 
(select Developer.country 
from Developer 
group by Developer.country
having count(*) > 10 )
group by Developer.country

--Q5
select A.name, A.category 
from Game as A where A.cost IN (
select Max(cost) 
from Game as B 
where A.category = B.category group by B.category)

--Q6
select [User].name 
from [User] join Downloads
on [User].userID = Downloads.userID 
where [User].userID NOT IN (
select Downloads.userID 
from Downloads 
where rating < 3)
group by [User].userID, [User].name
having count(Downloads.gameID) = (
select count(*)
from Game
)

--Q7
select Developer.name from Developer
where Developer.developerID IN 
(select Game.developID from Game group by Game.developID 
having count(*) = 3)
AND Developer.country = 'Iran'

--Q8
select A.name, B.name from [User] as A, [User] as B
where NOT EXISTS (
((select Downloads.gameID from Downloads
where A.userID = Downloads.userID) except
(select Downloads.gameID from Downloads
where B.userID = Downloads.userID))
UNION
((select Downloads.gameID from Downloads
where B.userID = Downloads.userID) except
(select Downloads.gameID from Downloads where A.userID = Downloads.userID))
) AND A.userID > B.userID

--Q9
Select *
from 
(Select developerID as DeveloperID, Developer.name as DeveloperName,Game.name as GameName
from Developer left outer join Game on developerID=developID) 
as DeveloperGame

--Q10
Select Downloads.userID, [User].name,[User].age, COUNT(*) as NoOfGames
from Downloads join [User] on (Downloads.userID = [User].userID) 
where [User].userID IN (
Select [User].userID 
FROM [User] 
where [User].age<18) AND [Downloads].gameID IN (
Select Game.gameID 
from Game 
where Game.cost>1000)
group by Downloads.[userID], [User].name, [User].age

--Q11
select Developer.name 
from Developer
where Developer.developerID IN (
select
Game.developID 
from Game
group by Game.developID 
having count(*) < 5)

--Q12
select Game.category, count(*) as [No of Games]
from Game 
where Game.developID IN
(select Developer.developerID 
from Developer 
where Developer.country = 'Pakistan')
group by Game.category

--Q13
select distinct [User].name 
from [User] join Downloads on [User].userID = Downloads.userID
where [User].userID NOT IN (
select Downloads.userID
from Downloads 
where rating < 5)

--Q14
select distinct [User].name 
from [User] join Downloads on [User].userID = Downloads.userID
where [User].userID NOT IN (
select Downloads.userID
from Downloads 
where rating < 3)

--Q15
select U.name 
from [User] as U 
where NOT EXISTS (
(select Downloads.gameID 
from Downloads 
group by Downloads.gameID
having AVG(Downloads.rating) >= 4)
except
(select Downloads.gameID 
from Downloads
where Downloads.userID = U.userID) 
)

--View 1
go
create view [GameInfo]
as 
select Developer.developerID, Developer.name as [Developer Name], Game.name as [Name of Game], Game.cost
from Developer join Game on Developer.developerID = Game.developID
go

select * from [GameInfo]

drop view [GameInfo]

--View 2
go
create view [YoungUser] as 
select [User].userID, [User].name, count(*) as [No of Games],
sum(Game.cost) as [Total Amount] 
from [User], Game, Downloads
where (Downloads.gameID = Game.gameID AND Downloads.userID = [User].userID 
AND [User].age < 18)
group by [User].userID, [User].name
having count(*) > 15
go

select * from [YoungUser]

drop view [YoungUser]

--Trigger 1
Go
create trigger underAgePurchase
on Downloads
for insert, update
as
if exists (select *
			from ((inserted as i join [User] as u on i.userID = u.userID) join Game as g on i.gameID = g.gameID)
			where u.age < 18 and g.cost > 500
			)
begin
	print 'Minor has purchased a game of worth more than Rs. 500'
end

----Trigger 2
Go
Create Trigger AvgRatingT
on Downloads
for Insert,Delete,Update
as 
If Exists(
Select D.gameID,AVG(D.rating) as 'Average Ratings' 
from [Downloads] as D
group by D.gameID
having AVG(D.rating)<2)
Begin
	IF exists(Select* from inserted) and not exists(Select* from deleted)   -- Insert Case
	begin
		declare @GID_Ins int
		Select @GID_Ins=gameID from inserted
		Print 'Average Rating of Game with id '+cast(@GID_Ins as varchar(10))+' Fallen below 2'
	end
	IF not exists(Select* from inserted) and exists(Select* from deleted)   -- Delete Case
	begin
		declare @GID_Del int
		Select @GID_Del=gameID from deleted
		Print 'Average Rating of Game with id '+cast(@GID_Del as varchar(10))+' Fallen below 2'
	end
	IF exists(Select* from inserted) and exists(Select* from deleted)   -- Update Case
	begin
		declare @GID_Up int
		Select @GID_Up=gameID from inserted
		Print 'Average Rating of Game with id '+cast(@GID_Up as varchar(10))+' Fallen below 2'
	end
End

