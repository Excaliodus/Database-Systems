create database CBZ

use CBZ

--A

create Table Developer
(
developerID int primary key,
name varchar(30),
country varchar(30),
specialty varchar(30),
)

create Table Game
(
gameID int primary key,
name varchar(30),
developID int,
cost int,
category varchar(30),
)

create Table [User]
(
userID int primary key,
name varchar(30),
country varchar(30),
age int,
)

create Table Downloads
(
gameID int,
userID int,
rating int check (rating >=1 AND rating <=5),
primary key (gameID,userID),
)


alter table Downloads add constraint FK_UserID
foreign key (userID) references 
[User] (userID)

alter table Downloads add constraint FK_gameID
foreign key (gameID) references 
Game (gameID)

alter table Game add constraint FK_developID
foreign key (developID) references 
Developer (developerID)

--B

insert into [User]
values (1, 'Hamza Sohail', 'Pakistan', 20) 
insert into [User]
values (2, 'John Smith', 'USA', 31) 
insert into [User]
values (3, 'Sufyan Amjad', 'Pakistan', 25) 
insert into [User]
values (4, 'Tariq Masood', 'Saudia Arabia', 36) 
insert into [User]
values (5, 'Franklin Wong', 'England', 22) 
insert into [User]
values (6, 'Ramesh Kumar', 'India', 28) 
insert into [User]
values (7, 'Abdullah', 'Turkey',17)

insert into Developer
values (111, 'Bilal Javed', 'Pakistan', 'Action')
insert into Developer
values (112, 'Zerox', 'China', 'Action')
insert into Developer
values (123, 'Ahmad', 'Pakistan', 'Racing')
insert into Developer
values (145, 'Ali', 'Turkey', 'Adventure')
insert into Developer
values (567, 'EA Sports', 'USA', 'Racing')
insert into Developer
values (872, 'Ubisoft', 'France', 'Adventure')
insert into Developer
values (956, 'Talha', 'Pakistan', 'Kids')
insert into Developer
values (562, 'John', 'Russia', 'Adventure')

insert into Game
values (2368, 'Angry Birds', 112, 0, 'Kids')
insert into Game
values (1276, 'Anger2', 112, 10, 'Kids')
insert into Game
values (8748, 'Assassin Creed', 872, 40, 'Adventure')
insert into Game
values (9443, 'Need for Speed', 567, 30, 'Racing')
insert into Game
values (6534, 'Counter Strike', 562, 0, 'Action')
insert into Game
values (2277, 'BattleField', 123, 0, 'Action')
insert into Game 
values (5432, 'Clash of Clans', 562,18, 'Kids')
insert into Game 
values (4531,'Flow2',956,5,'Kids')

insert into Downloads 
values (8748,1,4)

insert into Downloads 
values (1276,3,3)
insert into Downloads 
values (6534,4,5)
insert into Downloads 
values (2368,6,5)
insert into Downloads 
values (1276,5,1)
insert into Downloads 
values (8748,3,1)
insert into Downloads
values (5432, 2, 2)
insert into Downloads
values (2277, 1, 4)

-------------------
--part(a)
--1)
select Game.gameID, Game.name
from Developer join Game
on Developer.developerID = Game.developID
where Developer.name = 'Zerox'

--2
select userID
from Game join Developer on [Game].developID=[Developer].developerID join Downloads on [Game].gameID=[Downloads].gameID
where category='kids' and Developer.country='Russia'

--3
select [User].userID,[User].name
from Game join Downloads on [Game].gameID=[Downloads].gameID join [User] on [User].userID=[Downloads].userID
where category='action'
except
select [User].userID,[User].name
from Game join Downloads on [Game].gameID=[Downloads].gameID join [User] on [User].userID=[Downloads].userID
where category='kids'

--4
select [User].name,age
from Downloads join [User] on [Downloads].userID=[User].userID join Game on [Downloads].gameID=[Game].gameID
where Game.name='Angry Birds'
intersect
select [User].name,age
from Downloads join [User] on [Downloads].userID=[User].userID join Game on [Downloads].gameID=[Game].gameID
where Game.name='Anger2'


--5
select [User].userID,[User].name
from Game join Downloads on [Game].gameID=[Downloads].gameID join [User] on [User].userID=[Downloads].userID
where Game.name='Angry Birds'
except 
select[User].userID,[User].name
from Game join Downloads on Game.gameID=Downloads.gameID join [User] on [User].userID=[Downloads].userID
where Game.name='Anger2'

--6
select [User].userID 
from [User]
except 
select [User].userID from 
[User] join Downloads on ([User].userID = Downloads.userID)

--7
select [User].name,[User].userID
from Game join Downloads on Game.gameID=Downloads.gameID join [User] on [User].userID=[Downloads].userID
where cost=0


--8
select [User].name,[User].userID
from Game join Downloads on Game.gameID=Downloads.gameID join [User] on [User].userID=[Downloads].userID
where cost=0

except

select [User].name,[User].userID
from Game join Downloads on Game.gameID=Downloads.gameID join [User] on [User].userID=[Downloads].userID
where cost>0

--9
select distinct g.name,g.cost,d.name,g.gameID
from ((game as g inner join Developer as d on g.developID=d.developerID) inner join Downloads as f on f.gameID=g.gameID)
where f.rating>=3
except
select distinct g.name,g.cost,d.name,g.gameID
from ((game as g inner join Developer as d on g.developID=d.developerID) inner join Downloads as f on f.gameID=g.gameID)
where f.rating<3

--10
select distinct [User].userID
from Game join Downloads on Game.gameID=Downloads.gameID join Developer on Game.developID=Developer.developerID join [User] on [User].userID=[Downloads].userID
where Developer.name='Ahmed'


--11
select Game.gameID,Game.name,Developer.name
from Game join Developer on Game.developID=Developer.developerID
where cost=0


--12
select [User].name as Name
from [User]
where [User].country = 'Pakistan'
union
select [Developer].name as Name
from Developer
where [Developer].country = 'Pakistan'

--------------------------------------------------
--part(b)

--1
select Developer.developerID, Developer.name, count (*) as [No of Games]
from Developer join Game on (Developer.developerID = Game.developID)
group by Developer.developerID,  Developer.name
having count(*) < 5

--2
select Developer.developerID, count (*) as [No of Games]
from Developer join Game on (Developer.developerID = Game.developID)
group by Developer.developerID,  Developer.name
having count(*) = 2

--3
select max(rating) as [Max Ratings], min(rating) as [Min Ratings], avg(rating) as [Average Ratings]
from Downloads

--4
select Downloads.gameID, max(rating) as [Max Ratings], min(rating) as [Min Ratings], avg(rating) as [Average Ratings]
from Downloads
group by Downloads.gameID

--5
select count(*) as [No of Users]
from [User] 
where [User].age < 18

--6
select Game.developID, count (*) as [No of Games developed]
from Game
group by Game.developID

--7 
select count(*) as [No of Users]
from [User] 
where ([User].age < 18 AND [User].country = 'Pakistan')

--8
select Game.category, count (*) as [No of Games] from 
Game join Developer on (Game.developID = Developer.developerID and Developer.country = 'Pakistan')
group by Game.category